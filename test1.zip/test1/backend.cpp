#include "backend.h"
#include <QDebug>
#include <bitcoin/bitcoin.hpp>

BackEnd::BackEnd(QObject *parent) : QObject(parent)
{

}

QString BackEnd::userName() const
{
    return userName_;
}
void BackEnd::setuserName(const QString& userName)
{
    if (userName == userName_)
        return;
    userName_ = userName;
    emit userNameChanged();
}

QString BackEnd::genesisHash() const
{
    //QString hello("hello");
    auto blk = bc::message::block::genesis_mainnet();
    const auto h = blk.hash();
    std::string blk_hash = bc::encode_hash(h);
    std::cout << "testingtes:" << blk_hash << std::endl;
    qDebug() << "hola:" << QString::fromStdString(blk_hash);
    return QString::fromStdString(blk_hash);
    //return hello;
}
