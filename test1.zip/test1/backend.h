#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>
#include <QString>

class BackEnd
  : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString userName READ userName WRITE setuserName NOTIFY userNameChanged)
    Q_PROPERTY(QString genesisHash READ genesisHash CONSTANT)
public:
    explicit BackEnd(QObject *parent = nullptr);

    QString userName() const;
    void setuserName(const QString& userName);

    QString genesisHash() const;
signals:
    void userNameChanged();

private:
    QString userName_;
};

#endif // BACKEND_H
