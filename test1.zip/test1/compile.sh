#!/bin/bash
mkdir -p build
rm -fr build/*
qmake test1.pro
make
make install INSTALL_ROOT=/test1/build/
androiddeployqt --output build/ --input android-libtest1.so-deployment-settings.json --gradle

