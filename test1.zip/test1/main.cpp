#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <secp256k1.h>
#include <boost/lexical_cast.hpp>

#include "backend.h"

int main(int argc, char *argv[])
{
    secp256k1_context* ctx = secp256k1_context_create(SECP256K1_CONTEXT_NONE);
    secp256k1_context_destroy(ctx);

    int x = boost::lexical_cast<int>("5");

    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QGuiApplication app(argc, argv);

    qmlRegisterType<BackEnd>("io.qt.examples.backend", 1, 0, "BackEnd");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));
    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
